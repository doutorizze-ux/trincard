import React, { useState, useEffect, useMemo } from 'react';
import Layout from '../components/Layout';
import { 
  Search, 
  Filter, 
  MapPin, 
  Star, 
  Clock, 
  Phone, 
  Globe, 
  Tag,
  ChevronDown,
  Heart,
  Share2,
  ExternalLink
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Partner } from '../lib/supabase';
import { toast } from 'sonner';
import { useDebounce } from '../hooks/useDebounce';

export default function PartnersPage() {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedCity, setSelectedCity] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [favorites, setFavorites] = useState<string[]>([]);
  
  // Debounce search term to avoid excessive filtering
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const categories = [
    'Alimentação',
    'Esportes',
    'Saúde',
    'Educação',
    'Entretenimento',
    'Beleza',
    'Tecnologia',
    'Varejo',
    'Serviços'
  ];

  useEffect(() => {
    fetchPartners();
    loadFavorites();
  }, []);

  const fetchPartners = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('partners')
        .select('*')
        .eq('status', 'approved')
        .order('name');
      
      if (error) {
        toast.error('Erro ao carregar parceiros');
      } else {
        setPartners(data || []);
      }
    } catch (error) {
      console.error('Error fetching partners:', error);
      toast.error('Erro inesperado ao carregar parceiros');
    } finally {
      setLoading(false);
    }
  };

  const loadFavorites = () => {
    const saved = localStorage.getItem('trincard_favorites');
    if (saved) {
      setFavorites(JSON.parse(saved));
    }
  };

  const toggleFavorite = (partnerId: string) => {
    const newFavorites = favorites.includes(partnerId)
      ? favorites.filter(id => id !== partnerId)
      : [...favorites, partnerId];
    
    setFavorites(newFavorites);
    localStorage.setItem('trincard_favorites', JSON.stringify(newFavorites));
    
    toast.success(
      favorites.includes(partnerId) 
        ? 'Removido dos favoritos' 
        : 'Adicionado aos favoritos'
    );
  };

  const sharePartner = async (partner: Partner) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: partner.name,
          text: `Confira este parceiro do TrinCard: ${partner.name}`,
          url: window.location.href
        });
      } catch (error) {
        // User cancelled sharing
      }
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(
        `Confira este parceiro do TrinCard: ${partner.name} - ${window.location.href}`
      );
      toast.success('Link copiado para a área de transferência');
    }
  };

  // Memoize filtered partners to avoid recalculation on every render
  const filteredPartners = useMemo(() => {
    return partners.filter(partner => {
      const matchesSearch = partner.name?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
                           partner.description?.toLowerCase().includes(debouncedSearchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || partner.category === selectedCategory;
      const matchesCity = selectedCity === 'all' || partner.city === selectedCity;
      
      return matchesSearch && matchesCategory && matchesCity;
    });
  }, [partners, debouncedSearchTerm, selectedCategory, selectedCity]);

  // Memoize sorted partners to avoid recalculation on every render
  const sortedPartners = useMemo(() => {
    return [...filteredPartners].sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'category':
          return a.category.localeCompare(b.category);
        case 'city':
          return a.city.localeCompare(b.city);
        default:
          return 0;
      }
    });
  }, [filteredPartners, sortBy]);

  // Memoize unique cities to avoid recalculation
  const uniqueCities = useMemo(() => {
    return [...new Set(partners.map(p => p.city))].sort();
  }, [partners]);

  const formatPhone = (phone: string) => {
    if (!phone) return '';
    return phone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  };

  if (loading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando parceiros...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Nossos Parceiros
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Descubra estabelecimentos incríveis que oferecem benefícios exclusivos para portadores do TrinCard
            </p>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* Search */}
              <div className="lg:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Buscar parceiros..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Category Filter */}
              <div>
                <div className="relative">
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full appearance-none bg-white border border-gray-300 rounded-lg px-3 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="all">Todas as categorias</option>
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                </div>
              </div>

              {/* City Filter */}
              <div>
                <div className="relative">
                  <select
                    value={selectedCity}
                    onChange={(e) => setSelectedCity(e.target.value)}
                    className="w-full appearance-none bg-white border border-gray-300 rounded-lg px-3 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="all">Todas as cidades</option>
                    {uniqueCities.map(city => (
                      <option key={city} value={city}>{city}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                </div>
              </div>

              {/* Sort */}
              <div>
                <div className="relative">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full appearance-none bg-white border border-gray-300 rounded-lg px-3 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="name">Ordenar por nome</option>
                    <option value="category">Ordenar por categoria</option>
                    <option value="city">Ordenar por cidade</option>
                  </select>
                  <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* View Mode Toggle */}
            <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-200">
              <p className="text-sm text-gray-600">
                {sortedPartners.length} parceiro(s) encontrado(s)
              </p>
              
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                    viewMode === 'grid'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Grade
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                    viewMode === 'list'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Lista
                </button>
              </div>
            </div>
          </div>

          {/* Partners Grid/List */}
          {sortedPartners.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum parceiro encontrado</h3>
              <p className="text-gray-600">Tente ajustar os filtros de busca</p>
            </div>
          ) : (
            <div className={viewMode === 'grid' 
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
              : 'space-y-4'
            }>
              {sortedPartners.map((partner) => (
                <div
                  key={partner.id}
                  className={`bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow ${
                    viewMode === 'list' ? 'flex' : ''
                  }`}
                >
                  {/* Partner Image */}
                  <div className={`relative ${
                    viewMode === 'list' ? 'w-48 flex-shrink-0' : 'h-48'
                  }`}>
                    <img
                      src={partner.logo_url || `https://trae-api-us.mchost.guru/api/ide/v1/text_to_image?prompt=modern business logo for ${encodeURIComponent(partner.name)} ${encodeURIComponent(partner.category)}&image_size=square`}
                      alt={partner.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 right-3 flex space-x-2">
                      <button
                        onClick={() => toggleFavorite(partner.id)}
                        className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                          favorites.includes(partner.id)
                            ? 'bg-red-500 text-white'
                            : 'bg-white text-gray-600 hover:text-red-500'
                        }`}
                      >
                        <Heart className={`h-4 w-4 ${
                          favorites.includes(partner.id) ? 'fill-current' : ''
                        }`} />
                      </button>
                      <button
                        onClick={() => sharePartner(partner)}
                        className="w-8 h-8 bg-white text-gray-600 hover:text-blue-500 rounded-full flex items-center justify-center transition-colors"
                      >
                        <Share2 className="h-4 w-4" />
                      </button>
                    </div>
                    
                    {/* Category Badge */}
                    <div className="absolute bottom-3 left-3">
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <Tag className="h-3 w-3 mr-1" />
                        {partner.category}
                      </span>
                    </div>
                  </div>

                  {/* Partner Info */}
                  <div className={`p-6 ${viewMode === 'list' ? 'flex-1' : ''}`}>
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="text-xl font-bold text-gray-900">{partner.name}</h3>
                      <div className="flex items-center space-x-1">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="text-sm text-gray-600">4.8</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mb-4 line-clamp-2">
                      {partner.description}
                    </p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="h-4 w-4 mr-2 flex-shrink-0" />
                        <span>{typeof partner.address === 'object' ? partner.address.street : partner.address}, {partner.city || (typeof partner.address === 'object' ? partner.address.city : '')}</span>
                      </div>
                      
                      {partner.phone && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Phone className="h-4 w-4 mr-2 flex-shrink-0" />
                          <span>{formatPhone(partner.phone)}</span>
                        </div>
                      )}
                      
                      {partner.website && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Globe className="h-4 w-4 mr-2 flex-shrink-0" />
                          <a 
                            href={partner.website}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-green-600 hover:text-green-700 hover:underline"
                          >
                            Visitar site
                          </a>
                        </div>
                      )}
                      
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="h-4 w-4 mr-2 flex-shrink-0" />
                        <span>Seg-Sex: 9h às 18h</span>
                      </div>
                    </div>
                    
                    {/* Benefits */}
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-gray-900 mb-2">Benefícios:</h4>
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                        <p className="text-sm text-green-800 font-medium">
                          🎯 Desconto de 15% em todos os produtos
                        </p>
                        <p className="text-xs text-green-600 mt-1">
                          Válido para portadores do TrinCard
                        </p>
                      </div>
                    </div>
                    
                    {/* Action Button */}
                    <button className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2">
                      <span>Ver Detalhes</span>
                      <ExternalLink className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Load More Button */}
          {sortedPartners.length > 0 && (
            <div className="text-center mt-12">
              <button className="bg-white text-green-600 border-2 border-green-600 py-3 px-8 rounded-lg hover:bg-green-600 hover:text-white transition-colors font-semibold">
                Carregar Mais Parceiros
              </button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}