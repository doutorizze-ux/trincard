import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { 
  CreditCard, 
  Zap, 
  Shield, 
  Users, 
  Star, 
  ArrowRight,
  CheckCircle,
  Trophy,
  Target,
  Activity
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Plan } from '../lib/supabase';

export default function HomePage() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPlans();
  }, []);

  const fetchPlans = async () => {
    try {
      const { data, error } = await supabase
        .from('plans')
        .select('*')
        .eq('is_active', true)
        .order('price');

      if (error) {
        console.error('Error fetching plans:', error);
      } else {
        setPlans(data || []);
      }
    } catch (error) {
      console.error('Error fetching plans:', error);
    } finally {
      setLoading(false);
    }
  };

  const features = [
    {
      icon: CreditCard,
      title: 'Cartão Digital',
      description: 'Acesse seus benefícios direto do celular com código de barras único'
    },
    {
      icon: Zap,
      title: 'Ativação Instantânea',
      description: 'Comece a usar seus benefícios imediatamente após a assinatura'
    },
    {
      icon: Shield,
      title: 'Segurança Total',
      description: 'Seus dados protegidos com criptografia de ponta'
    },
    {
      icon: Users,
      title: 'Rede de Parceiros',
      description: 'Centenas de estabelecimentos esportivos em todo o país'
    }
  ];

  const benefits = [
    'Descontos exclusivos em academias e centros esportivos',
    'Acesso a eventos esportivos especiais',
    'Consultoria nutricional gratuita',
    'Avaliação física mensal',
    'Desconto em suplementos e equipamentos',
    'Acesso a aplicativo de treinos personalizados'
  ];

  const testimonials = [
    {
      name: 'Carlos Silva',
      role: 'Atleta Amador',
      content: 'O TrinCard revolucionou minha rotina de treinos. Os descontos são incríveis!',
      rating: 5
    },
    {
      name: 'Ana Santos',
      role: 'Personal Trainer',
      content: 'Recomendo para todos os meus alunos. A variedade de parceiros é impressionante.',
      rating: 5
    },
    {
      name: 'João Oliveira',
      role: 'Corredor',
      content: 'Economizo muito em equipamentos e suplementos. Vale cada centavo!',
      rating: 5
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-600 via-blue-600 to-green-700 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
                Seu Cartão de
                <span className="block text-yellow-300">Benefícios Esportivos</span>
              </h1>
              <p className="text-xl lg:text-2xl mb-8 text-green-100">
                Acesse descontos exclusivos em academias, centros esportivos e muito mais!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link
                  to="/cadastro"
                  className="bg-yellow-400 text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-yellow-300 transition-colors flex items-center justify-center space-x-2 shadow-lg"
                >
                  <Trophy className="h-5 w-5" />
                  <span>Começar Agora</span>
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <Link
                  to="/parceiros"
                  className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-green-600 transition-colors flex items-center justify-center space-x-2"
                >
                  <Users className="h-5 w-5" />
                  <span>Ver Parceiros</span>
                </Link>
              </div>
            </div>
            <div className="flex justify-center lg:justify-end">
              <div className="relative">
                <div className="w-80 h-48 bg-gradient-to-r from-gray-800 to-gray-900 rounded-2xl shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-300">
                  <div className="p-6 h-full flex flex-col justify-between">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-yellow-400 font-bold text-lg">TrinCard</h3>
                        <p className="text-gray-300 text-sm">Benefícios Esportivos</p>
                      </div>
                      <div className="w-12 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded"></div>
                    </div>
                    <div>
                      <div className="text-white font-mono text-lg tracking-wider mb-2">
                        **** **** **** 1234
                      </div>
                      <div className="flex justify-between text-gray-300 text-sm">
                        <span>JOÃO SILVA</span>
                        <span>12/27</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute -top-4 -right-4 w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center shadow-lg">
                  <Activity className="h-8 w-8 text-gray-900" />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-yellow-400 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-32 h-32 bg-blue-400 rounded-full opacity-10 animate-bounce"></div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Por que escolher o TrinCard?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Desenvolvido especialmente para entusiastas do esporte que buscam economia e qualidade
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center group hover:scale-105 transition-transform duration-300">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:shadow-lg transition-shadow">
                  <feature.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Plans Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Escolha seu Plano
            </h2>
            <p className="text-xl text-gray-600">
              Planos flexíveis para todos os perfis de atletas
            </p>
          </div>
          
          {loading ? (
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {plans.map((plan) => (
                <div key={plan.id} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden">
                  <div className="p-8">
                    <div className="text-center mb-6">
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                      <p className="text-gray-600 mb-4">{plan.description}</p>
                      <div className="text-4xl font-bold text-green-600 mb-2">
                        R$ {plan.price.toFixed(2)}
                        <span className="text-lg text-gray-500 font-normal">/mês</span>
                      </div>
                    </div>
                    
                    <div className="space-y-3 mb-8">
                      {benefits.slice(0, plan.name === 'Premium' ? 6 : plan.name === 'Plus' ? 4 : 3).map((benefit, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                          <span className="text-gray-700">{benefit}</span>
                        </div>
                      ))}
                    </div>
                    
                    <Link
                      to="/cadastro"
                      className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-green-700 hover:to-blue-700 transition-colors flex items-center justify-center space-x-2"
                    >
                      <Target className="h-5 w-5" />
                      <span>Escolher Plano</span>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                Benefícios Exclusivos
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Acesse uma rede completa de parceiros e serviços especializados no mundo esportivo
              </p>
              
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    </div>
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="bg-gradient-to-br from-green-100 to-green-200 p-6 rounded-xl">
                  <Trophy className="h-8 w-8 text-green-600 mb-3" />
                  <h4 className="font-semibold text-gray-900 mb-2">500+</h4>
                  <p className="text-sm text-gray-600">Parceiros Ativos</p>
                </div>
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 p-6 rounded-xl">
                  <Users className="h-8 w-8 text-blue-600 mb-3" />
                  <h4 className="font-semibold text-gray-900 mb-2">10k+</h4>
                  <p className="text-sm text-gray-600">Usuários Ativos</p>
                </div>
              </div>
              <div className="space-y-4 mt-8">
                <div className="bg-gradient-to-br from-yellow-100 to-yellow-200 p-6 rounded-xl">
                  <Star className="h-8 w-8 text-yellow-600 mb-3" />
                  <h4 className="font-semibold text-gray-900 mb-2">4.9</h4>
                  <p className="text-sm text-gray-600">Avaliação Média</p>
                </div>
                <div className="bg-gradient-to-br from-purple-100 to-purple-200 p-6 rounded-xl">
                  <Activity className="h-8 w-8 text-purple-600 mb-3" />
                  <h4 className="font-semibold text-gray-900 mb-2">24/7</h4>
                  <p className="text-sm text-gray-600">Suporte Online</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              O que nossos usuários dizem
            </h2>
            <p className="text-xl text-gray-600">
              Histórias reais de quem já faz parte da família TrinCard
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">"{testimonial.content}"</p>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Pronto para começar sua jornada esportiva?
          </h2>
          <p className="text-xl mb-8 text-green-100">
            Junte-se a milhares de atletas que já economizam com o TrinCard
          </p>
          <Link
            to="/cadastro"
            className="bg-yellow-400 text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-yellow-300 transition-colors inline-flex items-center space-x-2 shadow-lg"
          >
            <Trophy className="h-5 w-5" />
            <span>Cadastre-se Gratuitamente</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </Layout>
  );
}