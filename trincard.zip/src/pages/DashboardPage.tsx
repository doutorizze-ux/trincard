import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Layout from '../components/Layout';
import { 
  CreditCard, 
  QrCode, 
  Gift, 
  Calendar, 
  TrendingUp, 
  MapPin,
  Star,
  Clock,
  CheckCircle,
  ExternalLink
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Subscription, Benefit, BenefitUsage } from '../lib/supabase';
import JsBarcode from 'jsbarcode';
import QRCodeGenerator from '../components/QRCodeGenerator';
import { SkeletonCard, SkeletonList } from '../components/Skeleton';

export default function DashboardPage() {
  const { user, userProfile } = useAuth();
  const navigate = useNavigate();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [benefits, setBenefits] = useState<Benefit[]>([]);
  const [recentUsage, setRecentUsage] = useState<BenefitUsage[]>([]);
  const [loading, setLoading] = useState(true);
  const [barcodeDataUrl, setBarcodeDataUrl] = useState<string>('');
  const [lastFetch, setLastFetch] = useState<number>(0);

  const fetchUserData = useCallback(async () => {
    try {
      setLoading(true);
      setLastFetch(Date.now());
      
      // Fetch all data in parallel for better performance
      const [subscriptionResult, benefitsResult, usageResult] = await Promise.allSettled([
        supabase
          .from('subscriptions')
          .select(`
            *,
            plans (
              name,
              description,
              price
            )
          `)
          .eq('user_id', user!.id)
          .eq('status', 'active')
          .single(),
        
        supabase
          .from('benefits')
          .select('*')
          .eq('is_active', true)
          .limit(6),
        
        supabase
          .from('benefit_usage')
          .select(`
            *,
            benefits (
              title,
              description
            )
          `)
          .eq('user_id', user!.id)
          .order('used_at', { ascending: false })
          .limit(5)
      ]);

      // Handle subscription
      if (subscriptionResult.status === 'fulfilled') {
        const { data: subscriptionData, error: subError } = subscriptionResult.value;
        if (subError && subError.code !== 'PGRST116') {
          console.error('Error fetching subscription:', subError);
        } else {
          setSubscription(subscriptionData);
          // Generate barcode if user has subscription
          if (subscriptionData) {
            generateBarcode(subscriptionData.barcode);
          }
        }
      }

      // Handle benefits
      if (benefitsResult.status === 'fulfilled') {
        const { data: benefitsData, error: benefitsError } = benefitsResult.value;
        if (benefitsError) {
          console.error('Error fetching benefits:', benefitsError);
        } else {
          setBenefits(benefitsData || []);
        }
      }

      // Handle usage
      if (usageResult.status === 'fulfilled') {
        const { data: usageData, error: usageError } = usageResult.value;
        if (usageError) {
          console.error('Error fetching usage:', usageError);
        } else {
          setRecentUsage(usageData || []);
        }
      }
      
    } catch (error) {
      console.error('Error fetching user data:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  const shouldRefetch = useCallback(() => {
    const now = Date.now()
    return now - lastFetch > 30000 // Cache por 30 segundos
  }, [lastFetch])

  useEffect(() => {
    if (user && shouldRefetch()) {
      fetchUserData();
    }
  }, [user, shouldRefetch, fetchUserData]);



  const generateBarcode = (barcodeValue: string) => {
    try {
      const canvas = document.createElement('canvas');
      JsBarcode(canvas, barcodeValue, {
        format: 'CODE128',
        width: 2,
        height: 100,
        displayValue: true,
        fontSize: 14,
        textMargin: 8
      });
      setBarcodeDataUrl(canvas.toDataURL());
    } catch (error) {
      console.error('Error generating barcode:', error);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'text-green-600 bg-green-100';
      case 'expired':
        return 'text-red-600 bg-red-100';
      case 'cancelled':
        return 'text-gray-600 bg-gray-100';
      default:
        return 'text-yellow-600 bg-yellow-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Ativo';
      case 'expired':
        return 'Expirado';
      case 'cancelled':
        return 'Cancelado';
      default:
        return 'Pendente';
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <div className="bg-white rounded-lg shadow p-6 mb-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <SkeletonCard />
                  <SkeletonCard />
                  <SkeletonCard />
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <SkeletonCard />
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                  <SkeletonList items={4} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Olá, {userProfile?.full_name || 'Usuário'}! 👋
            </h1>
            <p className="text-gray-600">
              Bem-vindo ao seu painel TrinCard. Aqui você pode acessar seu cartão digital e gerenciar seus benefícios.
            </p>
          </div>

          {/* Subscription Status */}
          {subscription ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
              {/* Digital Card */}
              <div className="lg:col-span-2">
                <div className="bg-gradient-to-br from-green-600 via-blue-600 to-green-700 rounded-2xl p-8 text-white shadow-xl">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h2 className="text-2xl font-bold mb-2">TrinCard Digital</h2>
                      <p className="text-green-100">{subscription.plans?.name}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        getStatusColor(subscription.status)
                      }`}>
                        {getStatusText(subscription.status)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <p className="text-green-100 text-sm mb-1">Nome do Titular</p>
                    <p className="text-xl font-semibold">{userProfile?.full_name}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <p className="text-green-100 text-sm mb-1">Válido até</p>
                      <p className="font-semibold">{formatDate(subscription.end_date)}</p>
                    </div>
                    <div>
                      <p className="text-green-100 text-sm mb-1">Tipo de Cartão</p>
                      <p className="font-semibold capitalize">{userProfile?.card_type}</p>
                    </div>
                  </div>
                  
                  {/* Barcode */}
                  {barcodeDataUrl && (
                    <div className="bg-white rounded-lg p-4">
                      <div className="text-center">
                        <img 
                          src={barcodeDataUrl} 
                          alt="Código de barras" 
                          className="mx-auto mb-2"
                        />
                        <p className="text-gray-600 text-sm">Apresente este código nos estabelecimentos parceiros</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Quick Stats */}
              <div className="space-y-6">
                <div className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Economia Total</h3>
                      <p className="text-2xl font-bold text-green-600">R$ 450,00</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">Economizado este mês</p>
                </div>
                
                <div className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Gift className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Benefícios Usados</h3>
                      <p className="text-2xl font-bold text-blue-600">{recentUsage.length}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">Nos últimos 30 dias</p>
                </div>
                
                <div className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <Star className="h-5 w-5 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Parceiros</h3>
                      <p className="text-2xl font-bold text-yellow-600">{benefits.length}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">Disponíveis na sua região</p>
                </div>
              </div>
            </div>
          ) : (
            /* No Subscription */
            <div className="bg-white rounded-xl p-8 shadow-lg mb-8 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CreditCard className="h-8 w-8 text-gray-400" />
              </div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">
                Você ainda não possui uma assinatura ativa
              </h2>
              <p className="text-gray-600 mb-6">
                Assine um de nossos planos para começar a aproveitar os benefícios exclusivos
              </p>
              <button 
                onClick={() => navigate('/assinatura')}
                className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-700 hover:to-blue-700 transition-colors"
              >
                Ver Planos
              </button>
            </div>
          )}

          {/* Benefits Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Available Benefits */}
            <div className="bg-white rounded-xl shadow-lg">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                  <Gift className="h-5 w-5 text-green-600" />
                  <span>Benefícios Disponíveis</span>
                </h2>
              </div>
              <div className="p-6">
                {benefits.length > 0 ? (
                  <div className="space-y-4">
                    {benefits.slice(0, 5).map((benefit) => (
                      <div key={benefit.id} className="flex items-start space-x-3 p-4 border border-gray-200 rounded-lg hover:border-green-300 transition-colors">
                        <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Gift className="h-5 w-5 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 mb-1">{benefit.title}</h3>
                          <p className="text-sm text-gray-600 mb-2">{benefit.description}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-green-600">
                              {benefit.discount_percentage}% de desconto
                            </span>
                            <button className="text-sm text-blue-600 hover:text-blue-700 flex items-center space-x-1">
                              <span>Ver detalhes</span>
                              <ExternalLink className="h-3 w-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                    <button className="w-full text-center py-3 text-green-600 hover:text-green-700 font-medium">
                      Ver todos os benefícios
                    </button>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Gift className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Nenhum benefício disponível no momento</p>
                  </div>
                )}
              </div>
            </div>

            {/* QR Code Generator */}
            <div className="bg-white rounded-xl shadow-lg">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                  <QrCode className="h-5 w-5 text-green-600" />
                  <span>QR Code Digital</span>
                </h2>
              </div>
              <div className="p-6">
                <QRCodeGenerator 
                  userProfile={userProfile} 
                  subscription={subscription}
                />
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-lg">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-blue-600" />
                  <span>Atividade Recente</span>
                </h2>
              </div>
              <div className="p-6">
                {recentUsage.length > 0 ? (
                  <div className="space-y-4">
                    {recentUsage.map((usage) => (
                      <div key={usage.id} className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{usage.benefits?.title}</p>
                          <p className="text-sm text-gray-600">
                            Usado em {formatDate(usage.used_at)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Clock className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Nenhuma atividade recente</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <button className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow text-left group">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-200 transition-colors">
                <QrCode className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Gerar QR Code</h3>
              <p className="text-sm text-gray-600">Compartilhe seu cartão digitalmente</p>
            </button>
            
            <button className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow text-left group">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-200 transition-colors">
                <MapPin className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Encontrar Parceiros</h3>
              <p className="text-sm text-gray-600">Localize estabelecimentos próximos</p>
            </button>
            
            <button className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow text-left group">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-yellow-200 transition-colors">
                <Calendar className="h-6 w-6 text-yellow-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Histórico</h3>
              <p className="text-sm text-gray-600">Veja seu histórico de uso</p>
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
}