import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import Layout from '../components/Layout';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  CreditCard, 
  Edit3, 
  Save, 
  X, 
  Camera, 
  Shield, 
  Bell, 
  Eye, 
  EyeOff,
  Trash2,
  AlertTriangle,
  Settings
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

type TabType = 'profile' | 'security' | 'notifications' | 'admin' | 'danger';

export default function ProfilePage() {
  const { userProfile, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<TabType>('profile');
  const isAdmin = userProfile?.is_admin || false;
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Profile form data
  const [profileData, setProfileData] = useState({
    full_name: '',
    phone: '',
    cpf: '',
    address: '',
    city: '',
    state: '',
    zip_code: '',
    card_type: 'digital' as 'digital' | 'physical'
  });
  
  // Password form data
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  // Notification settings
  const [notifications, setNotifications] = useState({
    email_marketing: true,
    email_benefits: true,
    push_notifications: true,
    sms_notifications: false
  });

  useEffect(() => {
    if (userProfile) {
      setProfileData({
        full_name: userProfile.full_name || '',
        phone: userProfile.phone || '',
        cpf: userProfile.cpf || '',

        address: typeof userProfile.address === 'object' ? userProfile.address.street : (userProfile.address || ''),
        city: typeof userProfile.address === 'object' ? userProfile.address.city : (userProfile.city || ''),
        state: typeof userProfile.address === 'object' ? userProfile.address.state : (userProfile.state || ''),
        zip_code: typeof userProfile.address === 'object' ? userProfile.address.zip_code : (userProfile.zip_code || ''),
        card_type: (userProfile.card_type as 'digital' | 'physical') || 'digital'
      });
    }
  }, [userProfile]);

  const handleProfileUpdate = async () => {
    try {
      setLoading(true);
      
      const updateData = {
        full_name: profileData.full_name,
        phone: profileData.phone,
        cpf: profileData.cpf,

        address: {
          street: profileData.address,
          city: profileData.city,
          state: profileData.state,
          zip_code: profileData.zip_code
        },
        card_type: profileData.card_type
      };
      
      const { error } = await supabase
        .from('users')
        .update(updateData)
        .eq('id', userProfile?.id);
      
      if (error) {
        toast.error('Erro ao atualizar perfil');
      } else {
        await updateProfile(updateData);
        setIsEditing(false);
        toast.success('Perfil atualizado com sucesso!');
      }
    } catch (error) {
      toast.error('Erro inesperado');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChange = async () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('As senhas não coincidem');
      return;
    }
    
    if (passwordData.newPassword.length < 6) {
      toast.error('A nova senha deve ter pelo menos 6 caracteres');
      return;
    }
    
    try {
      setLoading(true);
      
      const { error } = await supabase.auth.updateUser({
        password: passwordData.newPassword
      });
      
      if (error) {
        toast.error('Erro ao alterar senha');
      } else {
        setPasswordData({
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        });
        toast.success('Senha alterada com sucesso!');
      }
    } catch (error) {
      toast.error('Erro inesperado');
    } finally {
      setLoading(false);
    }
  };

  const handleNotificationUpdate = async () => {
    try {
      setLoading(true);
      
      // In a real app, you would save notification preferences to the database
      // For now, we'll just save to localStorage
      localStorage.setItem('trincard_notifications', JSON.stringify(notifications));
      
      toast.success('Preferências de notificação atualizadas!');
    } catch (error) {
      toast.error('Erro ao atualizar preferências');
    } finally {
      setLoading(false);
    }
  };

  const handleAccountDeletion = async () => {
    const confirmed = window.confirm(
      'Tem certeza que deseja excluir sua conta? Esta ação não pode ser desfeita.'
    );
    
    if (!confirmed) return;
    
    try {
      setLoading(true);
      
      // In a real app, you would implement proper account deletion
      // This would involve deleting user data and deactivating the account
      toast.error('Funcionalidade em desenvolvimento');
    } catch (error) {
      toast.error('Erro ao excluir conta');
    } finally {
      setLoading(false);
    }
  };

  const formatCPF = (cpf: string) => {
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  };

  const formatPhone = (phone: string) => {
    return phone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  };

  const formatZipCode = (zipCode: string) => {
    return zipCode.replace(/(\d{5})(\d{3})/, '$1-$2');
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
            <div className="flex items-center space-x-6">
              <div className="relative">
                <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                  <User className="h-12 w-12 text-white" />
                </div>
                <button className="absolute bottom-0 right-0 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center hover:bg-green-700 transition-colors">
                  <Camera className="h-4 w-4" />
                </button>
              </div>
              
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900">
                  {userProfile?.full_name || 'Usuário'}
                </h1>
                <p className="text-gray-600">{userProfile?.email}</p>
                <div className="flex items-center space-x-4 mt-2">
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    <CreditCard className="h-3 w-3 mr-1" />
                    Cartão {userProfile?.card_type === 'physical' ? 'Físico' : 'Digital'}
                  </span>
                  <span className="text-sm text-gray-500">
                    Membro desde {new Date(userProfile?.created_at || '').toLocaleDateString('pt-BR')}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="bg-white rounded-xl shadow-lg">
            <div className="border-b border-gray-200">
              <nav className="flex space-x-8 px-6">
                {[
                  { id: 'profile', label: 'Perfil', icon: User },
                  { id: 'security', label: 'Segurança', icon: Shield },
                  { id: 'notifications', label: 'Notificações', icon: Bell },
                  ...(isAdmin ? [{ id: 'admin', label: 'Administração', icon: Settings }] : []),
                  { id: 'danger', label: 'Zona de Perigo', icon: AlertTriangle }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as TabType)}
                    className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === tab.id
                        ? tab.id === 'admin' ? 'border-purple-500 text-purple-600' : tab.id === 'danger' ? 'border-red-500 text-red-600' : 'border-green-500 text-green-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <tab.icon className="h-4 w-4" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>

            <div className="p-6">
              {/* Profile Tab */}
              {activeTab === 'profile' && (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-semibold text-gray-900">Informações Pessoais</h2>
                    {!isEditing ? (
                      <button
                        onClick={() => setIsEditing(true)}
                        className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <Edit3 className="h-4 w-4" />
                        <span>Editar</span>
                      </button>
                    ) : (
                      <div className="flex space-x-2">
                        <button
                          onClick={handleProfileUpdate}
                          disabled={loading}
                          className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                        >
                          <Save className="h-4 w-4" />
                          <span>Salvar</span>
                        </button>
                        <button
                          onClick={() => setIsEditing(false)}
                          className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
                        >
                          <X className="h-4 w-4" />
                          <span>Cancelar</span>
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Nome Completo
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={profileData.full_name}
                          onChange={(e) => setProfileData({...profileData, full_name: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      ) : (
                        <p className="text-gray-900">{profileData.full_name || 'Não informado'}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Telefone
                      </label>
                      {isEditing ? (
                        <input
                          type="tel"
                          value={profileData.phone}
                          onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      ) : (
                        <p className="text-gray-900">{profileData.phone ? formatPhone(profileData.phone) : 'Não informado'}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        CPF
                      </label>
                      <p className="text-gray-900">{profileData.cpf ? formatCPF(profileData.cpf) : 'Não informado'}</p>
                    </div>



                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Endereço
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={profileData.address}
                          onChange={(e) => setProfileData({...profileData, address: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      ) : (
                        <p className="text-gray-900">{profileData.address || 'Não informado'}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Cidade
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={profileData.city}
                          onChange={(e) => setProfileData({...profileData, city: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      ) : (
                        <p className="text-gray-900">{profileData.city || 'Não informado'}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Estado
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={profileData.state}
                          onChange={(e) => setProfileData({...profileData, state: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      ) : (
                        <p className="text-gray-900">{profileData.state || 'Não informado'}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        CEP
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={profileData.zip_code}
                          onChange={(e) => setProfileData({...profileData, zip_code: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      ) : (
                        <p className="text-gray-900">{profileData.zip_code ? formatZipCode(profileData.zip_code) : 'Não informado'}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Tipo de Cartão
                      </label>
                      {isEditing ? (
                        <select
                          value={profileData.card_type}
                          onChange={(e) => setProfileData({...profileData, card_type: e.target.value as 'digital' | 'physical'})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        >
                          <option value="digital">Digital</option>
                          <option value="physical">Físico</option>
                        </select>
                      ) : (
                        <p className="text-gray-900 capitalize">
                          {profileData.card_type === 'physical' ? 'Físico' : 'Digital'}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Security Tab */}
              {activeTab === 'security' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold text-gray-900">Segurança da Conta</h2>
                  
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-yellow-600" />
                      <h3 className="font-medium text-yellow-800">Alterar Senha</h3>
                    </div>
                    <p className="text-sm text-yellow-700 mt-1">
                      Mantenha sua conta segura alterando sua senha regularmente.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Senha Atual
                      </label>
                      <div className="relative">
                        <input
                          type={showCurrentPassword ? 'text' : 'password'}
                          value={passwordData.currentPassword}
                          onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                          className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                        <button
                          type="button"
                          onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          {showCurrentPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Nova Senha
                      </label>
                      <div className="relative">
                        <input
                          type={showNewPassword ? 'text' : 'password'}
                          value={passwordData.newPassword}
                          onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                          className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Confirmar Nova Senha
                      </label>
                      <div className="relative">
                        <input
                          type={showConfirmPassword ? 'text' : 'password'}
                          value={passwordData.confirmPassword}
                          onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                          className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    <button
                      onClick={handlePasswordChange}
                      disabled={loading || !passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword}
                      className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {loading ? 'Alterando...' : 'Alterar Senha'}
                    </button>
                  </div>
                </div>
              )}

              {/* Notifications Tab */}
              {activeTab === 'notifications' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold text-gray-900">Preferências de Notificação</h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <h3 className="font-medium text-gray-900">E-mails de Marketing</h3>
                        <p className="text-sm text-gray-600">Receba ofertas especiais e novidades</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={notifications.email_marketing}
                          onChange={(e) => setNotifications({...notifications, email_marketing: e.target.checked})}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <h3 className="font-medium text-gray-900">E-mails de Benefícios</h3>
                        <p className="text-sm text-gray-600">Notificações sobre novos benefícios disponíveis</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={notifications.email_benefits}
                          onChange={(e) => setNotifications({...notifications, email_benefits: e.target.checked})}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <h3 className="font-medium text-gray-900">Notificações Push</h3>
                        <p className="text-sm text-gray-600">Receba notificações no seu dispositivo</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={notifications.push_notifications}
                          onChange={(e) => setNotifications({...notifications, push_notifications: e.target.checked})}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <h3 className="font-medium text-gray-900">SMS</h3>
                        <p className="text-sm text-gray-600">Receba notificações por SMS</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={notifications.sms_notifications}
                          onChange={(e) => setNotifications({...notifications, sms_notifications: e.target.checked})}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                      </label>
                    </div>
                  </div>

                  <button
                    onClick={handleNotificationUpdate}
                    disabled={loading}
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Salvando...' : 'Salvar Preferências'}
                  </button>
                </div>
              )}

              {/* Admin Tab */}
              {activeTab === 'admin' && isAdmin && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold text-gray-900">Painel de Administração</h2>
                  
                  <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-6 mb-6">
                     <div className="flex items-center space-x-3 mb-4">
                       <Settings className="h-8 w-8 text-purple-600" />
                       <div>
                         <h3 className="text-lg font-semibold text-gray-900">Painel Administrativo Principal</h3>
                         <p className="text-sm text-gray-600">Acesso completo ao sistema de administração</p>
                       </div>
                     </div>
                     <Link
                       to="/admin"
                       className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                     >
                       <Settings className="h-4 w-4 mr-2" />
                       Acessar Painel Admin
                     </Link>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                     <div className="bg-white border border-gray-200 rounded-lg p-6">
                       <div className="flex items-center space-x-3">
                         <User className="h-8 w-8 text-purple-600" />
                         <div>
                           <h3 className="font-semibold text-gray-900">Gerenciar Usuários</h3>
                           <p className="text-sm text-gray-600">Visualizar e gerenciar contas de usuários</p>
                         </div>
                       </div>
                     </div>
 
                     <div className="bg-white border border-gray-200 rounded-lg p-6">
                       <div className="flex items-center space-x-3">
                         <CreditCard className="h-8 w-8 text-purple-600" />
                         <div>
                           <h3 className="font-semibold text-gray-900">Gerenciar Parceiros</h3>
                           <p className="text-sm text-gray-600">Adicionar e editar parceiros disponíveis</p>
                         </div>
                       </div>
                     </div>
 
                     <div className="bg-white border border-gray-200 rounded-lg p-6">
                       <div className="flex items-center space-x-3">
                         <Shield className="h-8 w-8 text-purple-600" />
                         <div>
                           <h3 className="font-semibold text-gray-900">Assinaturas</h3>
                           <p className="text-sm text-gray-600">Visualizar e gerenciar assinaturas</p>
                         </div>
                       </div>
                     </div>
                   </div>
                </div>
              )}

              {/* Danger Zone Tab */}
              {activeTab === 'danger' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold text-gray-900">Zona de Perigo</h2>
                  
                  <div className="bg-red-50 border border-red-200 rounded-lg p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <AlertTriangle className="h-6 w-6 text-red-600" />
                      <h3 className="text-lg font-semibold text-red-800">Excluir Conta</h3>
                    </div>
                    
                    <p className="text-red-700 mb-4">
                      Ao excluir sua conta, todos os seus dados serão permanentemente removidos. 
                      Esta ação não pode ser desfeita.
                    </p>
                    
                    <ul className="text-sm text-red-600 mb-6 space-y-1">
                      <li>• Seu perfil e dados pessoais serão excluídos</li>
                      <li>• Sua assinatura será cancelada</li>
                      <li>• Você perderá acesso a todos os benefícios</li>
                      <li>• Não será possível recuperar os dados</li>
                    </ul>
                    
                    <button
                      onClick={handleAccountDeletion}
                      disabled={loading}
                      className="flex items-center space-x-2 bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>{loading ? 'Processando...' : 'Excluir Minha Conta'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}