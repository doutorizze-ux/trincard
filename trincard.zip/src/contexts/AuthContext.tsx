import React, { createContext, useContext, useEffect, useState, useMemo, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import { User as AppUser } from '../lib/supabase';
import { useSafeTimeout } from '../hooks/useSafeTimeout';

interface AuthContextType {
  user: User | null;
  userProfile: AppUser | null;
  session: Session | null;
  loading: boolean;
  signUp: (email: string, password: string, userData: Partial<AppUser>) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<AppUser>) => Promise<{ error: any }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<AppUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const { setSafeTimeout } = useSafeTimeout();

  useEffect(() => {
    console.log('🚀 Inicializando AuthContext...');

    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('📋 Sessão inicial:', session ? 'Encontrada' : 'Não encontrada');
      if (session?.user) {
        console.log('👤 Usuário da sessão:', session.user.id, session.user.email);
      }

      setSession(session);
      setUser(session?.user ?? null);

      if (session?.user) {
        fetchUserProfile(session.user.id);
      } else {
        setUserProfile(null);
        setLoading(false);
      }
    }).catch(error => {
      console.error('❌ Erro ao obter sessão inicial:', error);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      setSession(session);
      setUser(session?.user ?? null);

      if (session?.user) {
        await fetchUserProfile(session.user.id);
      } else {
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      console.log('🔍 Buscando perfil do usuário com ID:', userId);

      // Timeout para evitar carregamento infinito
      const timeoutPromise = new Promise((_, reject) =>
        setSafeTimeout(() => reject(new Error('Timeout ao buscar perfil')), 10000)
      );

      const fetchPromise = supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      const { data, error } = await Promise.race([fetchPromise, timeoutPromise]) as any;

      if (error) {
        console.error('❌ Erro ao buscar perfil:', error);
        console.error('❌ Código do erro:', error.code);
        console.error('❌ Mensagem:', error.message);

        // Se usuário não existe na tabela users, apenas notificar ou retornar null
        // Não criar automaticamente para evitar conflito com o processo de Signup
        if (error.code === 'PGRST116' || error.message?.includes('No rows')) {
          console.log('⚠️ Usuário não encontrado na tabela users.');
          setUserProfile(null);
          return;
        }

        // Para outros erros, definir perfil como null
        setUserProfile(null);
      } else {
        console.log('✅ Perfil do usuário carregado:', data);
        console.log('👑 Is Admin:', data?.is_admin);
        setUserProfile(data);
      }
    } catch (error: any) {
      console.error('❌ Erro inesperado ao buscar perfil:', error);
      if (error.message === 'Timeout ao buscar perfil') {
        console.error('⏰ Timeout: Carregamento demorou mais de 10 segundos');
      }
      setUserProfile(null);
    } finally {
      setLoading(false);
    }
  };

  const createMissingUserProfile = async (userId: string) => {
    try {
      console.log('🔧 Criando perfil faltante para usuário:', userId);

      // Buscar dados do auth.users
      const { data: authUser } = await supabase.auth.getUser();

      if (!authUser.user) {
        console.error('❌ Usuário não encontrado no auth');
        return;
      }

      const profileData = {
        id: userId,
        email: authUser.user.email!,
        full_name: authUser.user.user_metadata?.full_name || 'Usuário',
        phone: authUser.user.user_metadata?.phone || '',
        cpf: authUser.user.user_metadata?.cpf || '',
        address: {
          street: '',
          city: '',
          state: '',
          zip_code: ''
        },
        card_type: 'digital' as const,
        is_active: true,
        is_admin: authUser.user.email === 'admin@trincard.com.br',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const { error: insertError } = await supabase
        .from('users')
        .insert(profileData);

      if (insertError) {
        console.error('❌ Erro ao criar perfil:', insertError);
      } else {
        console.log('✅ Perfil criado com sucesso');
        setUserProfile(profileData);
      }
    } catch (error) {
      console.error('❌ Erro ao criar perfil faltante:', error);
    }
  };

  const signUp = useCallback(async (email: string, password: string, userData: Partial<AppUser>) => {
    try {
      setLoading(true);

      console.log('🚀 Iniciando criação de conta...');
      console.log('📧 Email:', email);
      console.log('👤 Dados do usuário:', userData);

      // Sign up with Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        console.error('❌ Erro na autenticação Supabase:', error);
        console.error('❌ Código do erro:', error.status);
        console.error('❌ Mensagem do erro:', error.message);

        // Tratamento específico para rate limiting
        if (error.message.includes('429') || error.message.includes('Too Many Requests')) {
          return {
            error: {
              ...error,
              isRateLimit: true,
              message: 'Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.'
            }
          };
        }
        return { error };
      }

      console.log('✅ Usuário criado no Supabase Auth:', data.user?.id);

      // If user is created, add profile data
      if (data.user) {
        const profileData = {
          id: data.user.id,
          email: data.user.email!,
          full_name: userData.full_name || '',
          phone: userData.phone || '',
          cpf: userData.cpf || '',
          address: {
            street: userData.address || '',
            city: userData.city || '',
            state: userData.state || '',
            zip_code: userData.zip_code || ''
          },
          card_type: userData.card_type || 'digital',
          is_active: true,
          is_admin: false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };

        console.log('📝 Dados do perfil a serem inseridos:', profileData);

        const { error: profileError } = await supabase
          .from('users')
          .insert(profileData);

        if (profileError) {
          console.error('❌ Erro ao criar perfil do usuário:', profileError);

          if (profileError.code === '23505') { // Unique constraint violation
            let errorMessage = 'Já existe um cadastro com estes dados.';
            if (profileError.message?.includes('cpf')) {
              errorMessage = 'Este CPF já está cadastrado em outra conta.';
            } else if (profileError.message?.includes('email')) {
              errorMessage = 'Este email já está cadastrado.';
            }
            return { error: { message: errorMessage } };
          }

          return { error: profileError };
        }

        console.log('✅ Perfil do usuário criado com sucesso!');
      }

      return { error: null };
    } catch (error: any) {
      console.error('❌ Erro inesperado durante criação da conta:', error);
      console.error('❌ Stack trace:', error.stack);

      // Tratamento para erros de rede que podem incluir 429
      if (error.status === 429 || (error.message && error.message.includes('429'))) {
        return {
          error: {
            ...error,
            isRateLimit: true,
            message: 'Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.'
          }
        };
      }
      return { error };
    } finally {
      setLoading(false);
    }
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      return { error };
    } catch (error) {
      return { error };
    } finally {
      setLoading(false);
    }
  }, []);

  const signOut = useCallback(async () => {
    try {
      setLoading(true);
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  const updateProfile = async (updates: Partial<AppUser>) => {
    try {
      if (!user) {
        return { error: new Error('No user logged in') };
      }

      const { error } = await supabase
        .from('users')
        .update(updates)
        .eq('id', user.id);

      if (error) {
        return { error };
      }

      // Refresh user profile
      await fetchUserProfile(user.id);
      return { error: null };
    } catch (error) {
      return { error };
    }
  };

  const value = {
    user,
    userProfile,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    updateProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}